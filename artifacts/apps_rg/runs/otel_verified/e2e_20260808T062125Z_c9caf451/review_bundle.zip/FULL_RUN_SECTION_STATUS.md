# Full resume — per-section status

Run folder: `e2e_20260808T062125Z_c9caf451`

| Section | X3 | X2 | Product quality | Runtime | Judges / score | Display text |
|---|---|---|---|---|---|---|
| competencies | PRE_RUN:exception | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:exception` |
| unify_bullets | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| ibm_bullets | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| insurtech_bullets | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| ey_bullets | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| unify_narrative | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| ibm_narrative | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| insurtech_narrative | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| ey_narrative | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| executive_summary | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| headline | PRE_RUN:PHASE1_NO_RUN_DIR | UNKNOWN | UNKNOWN | UNKNOWN | — | — (missing) |
| ↳ pre-run | | | | | | `PRE_RUN:PHASE1_NO_RUN_DIR` |
| final_resume_aggregation | NOT_RUN | — | — | — | — | — (missing) |
